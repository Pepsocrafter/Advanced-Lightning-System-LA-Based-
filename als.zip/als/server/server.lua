RegisterNetEvent('siren_controller:server:SyncState', function(vehNet)
    local veh = NetworkGetEntityFromNetworkId(vehNet)

    if veh == 0 or not DoesEntityExist(veh) then return end

    local state = Entity(veh).state

	if state.stateEnsured then return end

	state:set('stateEnsured', true, true)
	state:set('sirenMode', 0, true)
	state:set('horn', false, true)
	state:set('lightsOn', false, true)
	state:set('indicatorL', false, true)
	state:set('indicatorR', false, true)
	state:set('hazards', false, true)
	state:set('keyLock', false, true)
	state:set('stage', 0, true)
	state:set('manualMode', false, true)
	state:set('cruise', false, true)
	state:set('park', false, true)
	state:set('rumbler', false, true)
end)