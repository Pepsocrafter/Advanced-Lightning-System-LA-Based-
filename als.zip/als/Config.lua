return {
    Controls = {
        -- Valid keys: https://docs.fivem.net/docs/game-references/input-mapper-parameter-ids/keyboard/

        airhorn         = 'E', -- (Default: E)
        sirenWail       = '1', -- (Default: 1)
        sirenYelp       = '2', -- (Default: 2)
        sirenPriority   = '3', -- (Default: 3)
        sirenManual     = 'R', -- (Default: R)
        rumblerActivate = '4', -- (Default: 4)
        stage1          = '5', -- (Default: 5)
        stage2          = '6', -- (Default: 6)
        stage3          = '7', -- (Default: 7)
        cycleStage      = 'Q', -- (Default: Q)
        leftIndicator   = 'MINUS', -- (Default: MINUS)
        rightIndicator  = 'EQUALS', -- (Default: EQUALS)
        hazards         = 'BACK', -- (Default: BACK)
        keyLock         = 'F9', -- (Default: F9)
        cruise          = 'F5' -- (Default: F5)
    },

    storageSavePrefix = 'siren_controller_storage', -- Example: community_name_siren_controller (THIS MUST BE UNIQUE!!)
    sirenParkKill = true, -- If true, disables sirens when the vehicle is parked (Default: true)
    useTertiaryTone = true, -- If true, will allow the use of a priority/third tone. (Default: true)
    cycleStageKeybind = true, -- If true, will enable the keybind (Default: Q) to cycle the stage. (Default: true)
    cruiseLightsPlugin = false, -- If true, enables the cruise lights plugin (Default: true)
    automaticParkModePlugin = false, -- If true, enables the automatic park mode plugin (Default: true)
    parkModeDelay = 500, -- Time (in ms) before the vehicle will automatically toggle to park mode. I don't reccomend anything lower than 500.(Default: 500)
    healthRepairThreshold = 970, -- The health at which the vehicle will NOT enter park mode, Min: 0, Max: 1000 (Default: 970)
    checkDoors = false, -- If true, will check if any of the vehicle's doors aren't latched before entering park mode. (Default: true)

    SirenPositions = { -- Default HUD positions
        ['smart-controller-siren-box'] = { position = { left = 0, top = 60 }, scale = 0.4 },
        ['code3-z3-siren-box'] = { position = { left = 0, top = 60 }, scale = 0.4 },
        ['whelen-handheld-siren-box'] = { position = { left = -4.8, top = 42 }, scale = 0.1 }
    },

    Sirens = {
        ['Federal Signal SSP3000B LEO'] = {
            soundset       = 'POLICE5_SOUNDSET', -- Example: 'AWCNAME_SOUNDSET'
            wail           = 'SIREN_SSP3000_WAIL',
            yelp           = 'SIREN_SSP3000_YELP',
            airhorn        = 'SIREN_SSP3000_HORN',
            priority       = 'SIREN_SSP3000_PRIORITY',
            downgradeSound = 'SSP3000B/Downgrade',
            upgradeSound   = 'SSP3000B/Upgrade',
            onSound        = 'SSP3000B/On',
            offSound       = 'SSP3000B/Off',
            stage3OffSound = 'SSP3000B/Stage3Off',
            pressSound     = 'SSP3000B/Press',
            textureDict    = 'smart-controller-siren-box'
        },

        ['Federal Signal SSP3000B SRF'] = {
            soundset       = 'POLICE2_SOUNDSET', -- Example: 'AWCNAME_SOUNDSET'
            wail           = 'SIREN_Z3_RMBLRWAIL',
            yelp           = 'SIREN_Z3_RMBLRYELP',
            airhorn        = 'SIREN_Z3_RMBLRHORN',
            priority       = 'SIREN_Z3_RMBLRPRIORITY',
            downgradeSound = 'SSP3000B/Downgrade',
            upgradeSound   = 'SSP3000B/Upgrade',
            onSound        = 'SSP3000B/On',
            offSound       = 'SSP3000B/Off',
            stage3OffSound = 'SSP3000B/Stage3Off',
            pressSound     = 'SSP3000B/Press',
            textureDict    = 'smart-controller-siren-box'
        },

        ['Federal Signal SSP3000B HLS'] = {
            soundset       = 'POLICE6_SOUNDSET', -- Example: 'AWCNAME_SOUNDSET'
            wail           = 'SIREN_SSP3000_RMBLRWAIL',
            yelp           = 'SIREN_SSP3000_RMBLRYELP',
            airhorn        = 'SIREN_SSP3000_RMBLRHORN',
            priority       = 'SIREN_SSP3000_RMBLRPRIORITY',
            downgradeSound = 'SSP3000B/Downgrade',
            upgradeSound   = 'SSP3000B/Upgrade',
            onSound        = 'SSP3000B/On',
            offSound       = 'SSP3000B/Off',
            stage3OffSound = 'SSP3000B/Stage3Off',
            pressSound     = 'SSP3000B/Press',
            textureDict    = 'smart-controller-siren-box'
        },

        ['Federal Signal SSP3000B FIR'] = {
            soundset       = 'POLICE3_SOUNDSET', -- Example: 'AWCNAME_SOUNDSET'
            wail           = 'SIREN_SAPPHIRE_WAIL',
            yelp           = 'SIREN_SAPPHIRE_YELP',
            airhorn        = 'SIREN_SAPPHIRE_HORN',
            priority       = 'SIREN_SAPPHIRE_PRIORITY',
            downgradeSound = 'SSP3000B/Downgrade',
            upgradeSound   = 'SSP3000B/Upgrade',
            onSound        = 'SSP3000B/On',
            offSound       = 'SSP3000B/Off',
            stage3OffSound = 'SSP3000B/Stage3Off',
            pressSound     = 'SSP3000B/Press',
            textureDict    = 'smart-controller-siren-box'
        },

        
        ['Federal Signal SSP3000B AMR'] = {
            soundset       = 'POLICE4_SOUNDSET', -- Example: 'AWCNAME_SOUNDSET'
            wail           = 'SIREN_SAPPHIRE_RMBLRWAIL',
            yelp           = 'SIREN_SAPPHIRE_RMBLRYELP',
            airhorn        = 'SIREN_SSP3000_RMBLRHORN',
            priority       = 'SIREN_SAPPHIRE_RMBLRPRIORITY',
            downgradeSound = 'SSP3000B/Downgrade',
            upgradeSound   = 'SSP3000B/Upgrade',
            onSound        = 'SSP3000B/On',
            offSound       = 'SSP3000B/Off',
            stage3OffSound = 'SSP3000B/Stage3Off',
            pressSound     = 'SSP3000B/Press',
            textureDict    = 'smart-controller-siren-box'
        },


        ['Federal Signal SSP3000B OLD'] = {
            soundset       = 'POLICE1_SOUNDSET', -- Example: 'AWCNAME_SOUNDSET'
            wail           = 'SIREN_Z3_WAIL',
            yelp           = 'SIREN_Z3_YELP',
            airhorn        = 'SIREN_Z3_HORN',
            priority       = 'SIREN_Z3_PRIORITY',
            downgradeSound = 'SSP3000B/Downgrade',
            upgradeSound   = 'SSP3000B/Upgrade',
            onSound        = 'SSP3000B/On',
            offSound       = 'SSP3000B/Off',
            stage3OffSound = 'SSP3000B/Stage3Off',
            pressSound     = 'SSP3000B/Press',
            textureDict    = 'smart-controller-siren-box'
        },
    },

    SirenAudioBanks = { -- All AWCs that should be loaded. You can create your own AWCs using https://github.com/BJDubb/SirenSharp, make sure you replace my AWCs and data files with yours if you make your own.
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE1', -- OLD (SIREN_Z3_WAIL, SIREN_Z3_YELP, SIREN_Z3_PRIORITY, SIREN_Z3_HORN,)
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE2', -- SRF (SIREN_Z3_RMBLRWAIL, SIREN_Z3_RMBLRYELP, SIREN_Z3,RMBLRPRIORITY, SIREN_Z3_RMBLRHORN)
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE3', -- FIR (SIREN_SAPPHIRE_WAIL, SIREN_SAPPHIRE_YELP, SIREN_SAPPHIRE_PRIORITY, SIREN_SAPPHIRE_HORN,)
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE4', -- AMR (SIREN_SAPPHIRE_RMBLRWAIL, SIREN_SAPPHIRE_RMBLRYELP, SIREN_SAPPHIRE_RMBLRPRIORITY, SIREN_SAPPHIRE_RMBLRHORN,)
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE5', -- LEO (SIREN_SSP3000_WAIL, SIREN_SSP3000_YELP, SIREN_SSP3000_PRIORITY, SIREN_SSP3000_HORN,)
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE6', -- HLS (SIREN_SSP3000_RMBLRWAIL, SIREN_SSP3000_RMBLRYELP, SIREN_SSP3000_RMBLRPRIORITY, SIREN_SSP3000_RMBLRHORN,)
        'DLC_FEDERAL_SIGNAL\\SSP3000B'
    },

    EquipmentSetups = { -- Equipment setups for each vehicle
        
    -- Los Angeles Police Department --
        [`16pdfpiu`] = {
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {9}, -- Extras to enable in stage 1
            stage2Extras = {9}, -- Extras to enable in stage 2
            stage3Extras = {8, 10}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {2, 4}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`16pdfpius`] = {    
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {8, 10}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {2, 4}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`20pdfpiu`] = {
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {9}, -- Extras to enable in stage 1
            stage2Extras = {9}, -- Extras to enable in stage 2
            stage3Extras = {8, 10}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {2, 4}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`20pdfpius`] = {    
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {2, 4}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`15pdfpis`] = {
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {9}, -- Extras to enable in stage 1
            stage2Extras = {9}, -- Extras to enable in stage 2
            stage3Extras = {8, 10}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {2, 4}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`11pdcvpi`] = {    
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {9}, -- Extras to enable in stage 1
            stage2Extras = {9}, -- Extras to enable in stage 2
            stage3Extras = {8, 10}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {2, 4}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`11pdcvpis`] = {    
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {2, 4}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`sbearcat`] = {    
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`uc18gt`] = {    
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 3, 4, 5, 6, 7, 8, 9}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`bmwbike`] = {    
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`dfd18chgr`] = {    
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 3}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },
        
        [`ipack2rb`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 3, 4, 7, 8, 10, 11, 12}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`wardenboat2`] = {    
            siren = 'Federal Signal SSP3000B LEO', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },


-- Los Angeles Sheriff Department --

        [`18lasdchrg`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {3, 12, 2, 11}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

       [`lasd11`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 4, 5, 12}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

       [`lasd12`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 4, 5, 6, 7, 8}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

       [`lasd13`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 4, 5}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`ipack3rb`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 3, 4, 7, 8, 10, 11, 12}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`ipack4rb`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 3, 4, 7, 8, 10, 11, 12}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`bearcatrbstairs`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 3, 4, 7, 8, 10, 11, 12}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`wardenboat1`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`16fpiuk9rb`] = {    
            siren = 'Federal Signal SSP3000B SRF', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

    -- Los Angeles Fire Department --
        [`lafdbatt`] = {
            siren = 'Federal Signal SSP3000B AMR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 7, 8, 9}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`lafdtiller`] = {
            siren = 'Federal Signal SSP3000B FIR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 6, 7}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`lafdcab`] = {
            siren = 'Federal Signal SSP3000B FIR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 6, 7}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`lafdxt6700`] = {
            siren = 'Federal Signal SSP3000B FIR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 3}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`wardenboat3`] = {
            siren = 'Federal Signal SSP3000B AMR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

    -- American Medical Response --
        [`fordambo`] = {
            siren = 'Federal Signal SSP3000B AMR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 5, 6, 7, 8, 11, 12}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`amrvan`] = {
            siren = 'Federal Signal SSP3000B AMR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 3, 4, 5}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`amr02tahoe`] = {
            siren = 'Federal Signal SSP3000B AMR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 3, 4, 5, 6, 7, 8, 9}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`22FPIUAMR`] = {
            siren = 'Federal Signal SSP3000B AMR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 5, 6, 7, 8, 12}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`18tahoeamr`] = {
            siren = 'Federal Signal SSP3000B AMR', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 4, 5, 6, 7, 8, 11, 12}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

    
-- Retro Police Units (optional) --
        [`lspdlapdimpaler`] = {
            siren = 'Federal Signal SSP3000B OLD', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 3, 4, 5}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {}, -- Extras to enable in day park mode
            nightParkModeExtras = {}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {`policeold2`}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },


-- Homeland Security (optional) --
        [`sheriff`] = {
            siren = 'Federal Signal SSP3000B HLS', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {3, 4, 5}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {2}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = false, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {7, 8, 9}, -- Extras to enable in day park mode
            nightParkModeExtras = {10}, -- Extras to enable in night park mode
            driveModeExtras = {3, 4, 5}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {`gpd2`}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {11} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

-- Sonstige --



    },
}