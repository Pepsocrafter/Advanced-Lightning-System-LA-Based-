fx_version 'cerulean'
game 'gta5'
use_experimental_fxv2_oal 'yes'

author 'doublelegacylucas'
description 'Advanced Lighting System (ALS)'

lua54 'yes'

dependencies {
    '/onesync',
    'ox_lib'
}

ui_page 'ui/html/index.html'

shared_script '@ox_lib/init.lua'

client_script 'client/**.lua'

server_script 'server/*.lua'

files {
    'Config.lua',
    'audio/**/',
    'ui/**'
}

data_file 'AUDIO_WAVEPACK' 'audio/sfx/dlc_siren_controller_sirens'
data_file 'AUDIO_SOUNDDATA' 'audio/data/siren_controller_sirens.dat'

escrow_ignore {
    'Config.lua',
    'client/helptext.lua'
}

provide {
    'ulc',
    'lvc',
    'BozLights',
    'Server-Sided-Sounds-and-Sirens',
    'luxart-vehicle-control-fleet',
    'lvc-fleet'
}