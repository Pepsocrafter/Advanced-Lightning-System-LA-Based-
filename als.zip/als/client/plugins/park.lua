local Config = require 'Config'

if not Config.automaticParkModePlugin then return end

local vehsImSyncedWith = {}

local function doChecks()
    local areDoorsOpen
    local vehicle = cache.vehicle or GetPlayersLastVehicle()
    local vehHealth = GetVehicleBodyHealth(vehicle)
    local numberOfDoors = GetNumberOfVehicleDoors(vehicle)

    if Config.checkDoors then
        for i = 0, numberOfDoors, 1 do
            if GetVehicleDoorAngleRatio(vehicle, i) > 0.0 then
                areDoorsOpen = true
                break
            end
        end
    end

    if vehHealth > Config.healthRepairThreshold and not areDoorsOpen and GetIsVehicleEngineRunning(vehicle) or not cache.vehicle then
        return true
    end

    return false
end

local function vehicleDrive(forced)
    if not cache.vehicle then return end
    local state = Entity(cache.vehicle).state
    if not state.stateEnsured or not doChecks() then return end

    local model = GetEntityModel(cache.vehicle)

    if state.lightsOn and Config.EquipmentSetups[model] and Config.EquipmentSetups[model].useParkMode or forced then
        if Config.EquipmentSetups[model].useTimeBasedParkModes then
            for i = 1, #Config.EquipmentSetups[model].nightParkModeExtras do
                SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[model].nightParkModeExtras[i], true)
            end

            for i = 1, #Config.EquipmentSetups[model].dayParkModeExtras do
                SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[model].dayParkModeExtras[i], true)
            end
        else
            for i = 1, #Config.EquipmentSetups[model].parkModeExtras do
                SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[model].parkModeExtras[i], true)
            end
        end

        for i = 1, #Config.EquipmentSetups[model].stage3Extras do
            SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[model].stage3Extras[i], false)
        end
    end

    SendNUIMessage({
        _type = 'hud',
        item = 'park',
        state = false
    })

    stage1:disable(false)
    stage2:disable(false)
    stage3:disable(false)
    vehsImSyncedWith = {}
    state:set('park', false, true)
end

local function parkMode()
    local vehicle = cache.vehicle or GetPlayersLastVehicle()
    if not vehicle then return end
    local state = Entity(vehicle).state
    if not state.stateEnsured or not doChecks() or not GetVehicleClass(vehicle) == 18 then return end

    local vehModel = GetEntityModel(vehicle)

    if state.lightsOn and state.stage == 3 and Config.EquipmentSetups[vehModel].useParkMode or forced then
        if state.stage == 1 then
            stage2:disable(true)
            stage3:disable(true)
        elseif state.stage == 2 then
            stage1:disable(true)
            stage3:disable(true)
        elseif state.stage == 3 then
            stage1:disable(true)
            stage2:disable(true)
        end

        SendNUIMessage({
            _type = 'hud',
            item = 'park',
            state = true
        })

        for i = 1, #Config.EquipmentSetups[vehModel].driveModeExtras do
            SetVehicleExtra(vehicle, Config.EquipmentSetups[vehModel].driveModeExtras[i], true)
        end

        if Config.EquipmentSetups[vehModel].useTimeBasedParkModes then
            local _, lightsOn, highbeams = GetVehicleLightsState(vehicle)

            if lightsOn or highbeams then
                for i = 1, #Config.EquipmentSetups[vehModel].nightParkModeExtras do
                    SetVehicleExtra(vehicle, Config.EquipmentSetups[vehModel].nightParkModeExtras[i], false)
                end

                for i = 1, #Config.EquipmentSetups[vehModel].dayParkModeExtras do
                    SetVehicleExtra(vehicle, Config.EquipmentSetups[vehModel].dayParkModeExtras[i], true)
                end
            else
                for i = 1, #Config.EquipmentSetups[vehModel].dayParkModeExtras do
                    SetVehicleExtra(vehicle, Config.EquipmentSetups[vehModel].dayParkModeExtras[i], false)
                end

                for i = 1, #Config.EquipmentSetups[vehModel].nightParkModeExtras do
                    SetVehicleExtra(vehicle, Config.EquipmentSetups[vehModel].nightParkModeExtras[i], true)
                end
            end
        else
            for i = 1, #Config.EquipmentSetups[vehModel].parkModeExtras do
                SetVehicleExtra(vehicle, Config.EquipmentSetups[vehModel].parkModeExtras[i], false)
            end
        end

        if Config.EquipmentSetups[vehModel].carsToSyncWith and #Config.EquipmentSetups[vehModel].carsToSyncWith > 0 then
            local vehPool = GetGamePool('CVehicle')
            local vehsToSyncWith = {}
            vehsImSyncedWith = {}

            for _, v in pairs(vehPool) do
                if v ~= cache.vehicle and v ~= GetPlayersLastVehicle() then
                    local dist = #(GetEntityCoords(v) - GetEntityCoords(vehicle))

                    if dist < 30 and GetVehicleClass(v) == 18 then
                        for i = 1, #Config.EquipmentSetups[vehModel].carsToSyncWith do
                            if GetEntityModel(v) == Config.EquipmentSetups[vehModel].carsToSyncWith[i] then
                                print(('Vehicle \'%s\' is in range, checking if it is eligible'):format(v))

                                if IsVehicleStopped(v) and IsVehicleSirenOn(v) then
                                    print(('Vehicle \'%s\' is not moving, adding to eligible sync vehicles'):format(v))
                                    vehsToSyncWith[#vehsToSyncWith + 1] = v
                                end
                            end
                        end
                    end
                end
            end

            if #vehsToSyncWith > 0 then
                print('Syncing my vehicle')
                SetVehicleSiren(vehicle, false)
                SetVehicleSiren(vehicle, true)
                SetVehicleHasMutedSirens(vehicle, true)

                for i = 1, #vehsToSyncWith do
                    if IsVehicleSirenOn(vehsToSyncWith[i]) then
                        vehsImSyncedWith[#vehsImSyncedWith + 1] = VehToNet(vehsToSyncWith[i])
                        print(('Syncing vehicle \'%s\' on my client'):format(vehsToSyncWith[i]))
                        SetVehicleSiren(vehsToSyncWith[i], false)
                        SetVehicleSiren(vehsToSyncWith[i], true)
                        SetVehicleHasMutedSirens(vehsToSyncWith[i], true)
                    end
                end
            end

            state:set('park', true, true)
        end
    end
end

local function checkParkState()
    CreateThread(function()
        local vehicle = cache.vehicle or GetPlayersLastVehicle()
        local state = Entity(vehicle).state

        if not IsVehicleStopped(vehicle) and state.park then
            vehicleDrive()
        end

        if state.park and state.stateEnsured and not state.lightsOn then
            vehicleDrive(true)
        end

        if IsVehicleStopped(vehicle) and not state.park then
            Wait(1000)

            if not state.park then
                parkMode()
            end
        end
    end)
end

CreateThread(function()
    while true do
        if cache.vehicle or (GetPlayersLastVehicle() > 0 and GetPedInVehicleSeat(GetPlayersLastVehicle(), -1) == 0) then
            checkParkState()

            Wait(Config.parkModeDelay)
        else
            Wait(1500)
        end
    end
end)

stateBagWrapper('park', function(veh, value)
    if vehsImSyncedWith[VehToNet(veh)] then
        print('Recv new park state for vehicle im already synced with, skipping...')
        return
    end

    if NetworkGetEntityOwner(veh) == cache.playerId then
        print('Recv new park state for my vehicle, skipping...')
        return
    end

    print(('Recv new park state for %s: %s'):format(veh, value))

    if value then
        SetVehicleSiren(veh, false)
        SetVehicleSiren(veh, true)
        SetVehicleHasMutedSirens(veh, true)
    else
        SetVehicleSiren(veh, false)
        SetVehicleHasMutedSirens(veh, true)
    end
end)