local Config = require 'Config'

if not Config.cruiseLightsPlugin then return end

lib.addKeybind({
    name = 'cruise',
    description = 'Cruise lights',
    defaultKey = Config.Controls.cruise,
    onPressed = function()
        if not isVehAllowed(true) then return end
        local state = Entity(cache.vehicle).state
        if not state.stateEnsured then return end
        if not Config.EquipmentSetups[GetEntityModel(cache.vehicle)].useCruiseLights then return end
        if state.keyLock then
            SendNUIMessage({
                _type = 'audio',
                file = 'Locked_Press',
                volume = 0.2
            })
            notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

            return
        end

        for i = 1, #Config.EquipmentSetups[GetEntityModel(cache.vehicle)].cruiseLightExtras do
            SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[GetEntityModel(cache.vehicle)].cruiseLightExtras[i], state.cruise)
        end

        for i = 1, #Config.EquipmentSetups[GetEntityModel(cache.vehicle)].stage1Extras do
            SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[GetEntityModel(cache.vehicle)].stage1Extras[i], true)
        end

        for i = 1, #Config.EquipmentSetups[GetEntityModel(cache.vehicle)].stage2Extras do
            SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[GetEntityModel(cache.vehicle)].stage2Extras[i], true)
        end

        for i = 1, #Config.EquipmentSetups[GetEntityModel(cache.vehicle)].stage3Extras do
            SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[GetEntityModel(cache.vehicle)].stage3Extras[i], true)
        end

        for i = 1, #Config.EquipmentSetups[GetEntityModel(cache.vehicle)].parkModeExtras do
            SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[GetEntityModel(cache.vehicle)].parkModeExtras[i], true)
        end

        for i = 1, #Config.EquipmentSetups[GetEntityModel(cache.vehicle)].dayParkModeExtras do
            SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[GetEntityModel(cache.vehicle)].dayParkModeExtras[i], true)
        end

        for i = 1, #Config.EquipmentSetups[GetEntityModel(cache.vehicle)].nightParkModeExtras do
            SetVehicleExtra(cache.vehicle, Config.EquipmentSetups[GetEntityModel(cache.vehicle)].nightParkModeExtras[i], true)
        end

        if state.stage > 0 and state.cruise then
            local currentStage = ('stage%sExtras'):format(state.stage)
            local stageExtras = Config.EquipmentSetups[GetEntityModel(cache.vehicle)][currentStage]

            if not stageExtras then return end

            for i = 1, #stageExtras do
                SetVehicleExtra(cache.vehicle, stageExtras[i], false)
            end
        else
            state:set('lightsOn', not state.cruise, true)
        end

        state:set('cruise', not state.cruise, true)

        SendNUIMessage({
            _type  = 'audio',
            file   = Config.Sirens[currentSiren].pressSound,
            volume = 0.7
        })

        SendNUIMessage({
            _type = 'hud',
            item = 'cruise',
            state = state.cruise
        })
    end
})