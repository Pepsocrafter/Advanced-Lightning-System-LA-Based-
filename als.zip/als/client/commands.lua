---@diagnostic disable: param-type-mismatch
local Config = require 'Config'

hudShown = true
local focus

CreateThread(function()
    Wait(500)

    SendNUIMessage({ _type = 'setResourceName', resourceName = cache.resourceName})

    for k, v in pairs(Config.SirenPositions) do
        lib.print.verbose('Retrieving KVP for: ', k)
        local scale = GetResourceKvpFloat(('%s_%s_hud_scale'):format(Config.storageSavePrefix, k))
        if scale == 0 then scale = v.scale end
        local position = json.decode(GetResourceKvpString(('%s_%s_hud_position'):format(Config.storageSavePrefix, k))) or v.position

        lib.print.verbose('Retrieved KVP: ', scale, position)

        SendNUIMessage({ _type = 'setHudScale', hud = k, scale = scale})
        SendNUIMessage({ _type = 'setHudPosition', hud = k, position = position})
    end

    while true do
        SendNUIMessage({ _type = 'getHudState'})

        Wait(1000)
    end
end)

RegisterCommand('resethudposition', function()
    if not hudShown then
        notify('You must be in a vehicle with the HUD active to reset the HUD position.')
        return
    end

    SendNUIMessage({ _type = 'resetHudPosition' })
    SetResourceKvp(('%s_%s_hud_position'):format(Config.storageSavePrefix, currentSirenboxUi), json.encode({ left = Config.SirenPositions[currentSirenboxUi].position.left, top = Config.SirenPositions[currentSirenboxUi].position.top }))

    local leftPosition = Config.SirenPositions[currentSirenboxUi].position.left
    local topPosition = Config.SirenPositions[currentSirenboxUi].position.top
    notify(('HUD position saved and reset.'):format(leftPosition, topPosition))
end, false)

RegisterCommand('movemode', function()
    if not hudShown then
        notify('You must be in a vehicle with the HUD active to activate move-mode.')
        return
    end

    focus = not focus
    SetNuiFocus(focus, focus)
    CreateThread(function()
        while focus do
            DisplayHelpTextThisFrame('move_mode_help_text', false)

            Wait(0)
        end
    end)
end, false)

RegisterCommand('sethudscale', function(_, args, _)
    if not hudShown then
        notify('You must be in a vehicle with the HUD active to change the HUD scale.')
        return
    end

    local scale = tonumber(args[1])

    if scale and scale >= 0.1 and scale <= 1 then
        SendNUIMessage({ _type = 'setHudScale', scale = scale, hud = currentSirenboxUi })
        SetResourceKvpFloat(('%s_%s_hud_scale'):format(Config.storageSavePrefix, currentSirenboxUi), scale)
        notify(('HUD scale saved and set to %s'):format(scale))
    else
        notify('Scale must be between 0.1 and 1.')
    end
end, false)

RegisterCommand('resethudscale', function()
    if not hudShown then
        notify('You must be in a vehicle with the HUD active to reset its scale.')
        return
    end

    SendNUIMessage({ _type = 'resetHudScale', scale = Config.SirenPositions[currentSirenboxUi].scale })
    SetResourceKvpFloat(('%s_%s_hud_scale'):format(Config.storageSavePrefix, currentSirenboxUi), Config.SirenPositions[currentSirenboxUi].scale)
    notify(('HUD scale saved and reset to %s'):format(Config.SirenPositions[currentSirenboxUi].scale))
end, false)

RegisterCommand('togglehud', function()
    if not cache.vehicle then
        notify('You must be in a vehicle to toggle the HUD.')
        return
    end

    local hudKvp = GetResourceKvpInt(('%s_%s_hud_enabled'):format(Config.storageSavePrefix, currentSirenboxUi))
    hudShown = hudKvp == 2 or hudKvp == 0

    SendNUIMessage({
        _type = 'hud',
        item = 'toggle',
        state = not hudShown
    })
    notify(not hudShown and 'HUD enabled.' or 'HUD disabled.')
    SetResourceKvpInt(('%s_%s_hud_enabled'):format(Config.storageSavePrefix, currentSirenboxUi), not hudShown and 2 or 1)
end, false)

RegisterNUICallback('setMoveState', function(state, cb)
    SetNuiFocus(state, state)
    focus = state
end)

RegisterNUICallback('setHudPosition', function(data, cb)
    SetResourceKvp(('%s_%s_hud_position'):format(Config.storageSavePrefix, currentSirenboxUi), json.encode(data))
    notify(('HUD position saved and set to %s, %s.'):format(data.left, data.top))
end)

RegisterNUICallback('receiveHudState', function(data, cb)
    hudShown = data.state
end)