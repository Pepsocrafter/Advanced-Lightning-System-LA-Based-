AddTextEntry('move_mode_help_text', 'You\'re in move-mode. Press ~INPUT_FRONTEND_PAUSE_ALTERNATE~ or ~INPUT_VEH_AIM~ to exit.')
TriggerEvent('chat:addSuggestion', '/movemode', 'Toggle move-mode for the siren-controller HUD.')
TriggerEvent('chat:addSuggestion', '/sethudscale', 'Change the scale of the siren-controller HUD.', {
    { name = 'scale', help = 'Scale between 0.1 and 1' }
})
TriggerEvent('chat:addSuggestion', '/resethudscale', 'Reset the scale of the siren-controller HUD.')
TriggerEvent('chat:addSuggestion', '/resethudposition', 'Reset the position of the siren-controller HUD.')
TriggerEvent('chat:addSuggestion', '/togglehud', 'Toggles the siren-controller HUD.')