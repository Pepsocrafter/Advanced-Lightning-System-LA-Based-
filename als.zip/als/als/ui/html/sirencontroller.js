let currentSoundId = 0;
let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
let currentSirenbox = 'smart-controller-siren-box';
let resourceName = 'advanced_lighting_system';

const audioPlayers = new Map();

const sirenBoxes = {
    'smart-controller-siren-box': document.getElementById('smart-controller-siren-box'),
    'code3-z3-siren-box': document.getElementById('code3-z3-siren-box'),
    'whelen-handheld-siren-box': document.getElementById('whelen-handheld-siren-box')
};

const backup = {
    'smart-controller-siren-box': { left: sirenBoxes['smart-controller-siren-box'].style.left, top: sirenBoxes['smart-controller-siren-box'].style.top, scale: 0.4 },
    'code3-z3-siren-box': { left: sirenBoxes['code3-z3-siren-box'].style.left, top: sirenBoxes['code3-z3-siren-box'].style.top, scale: 0.35 },
    'whelen-handheld-siren-box': { left: sirenBoxes['whelen-handheld-siren-box'].style.left, top: sirenBoxes['whelen-handheld-siren-box'].style.top, scale: 0.1 }
};

Object.values(sirenBoxes).forEach(box => {
    box.onmousedown = dragMouseDown;
});

function dragMouseDown(e) {
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
}

function elementDrag(e) {
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;

    const box = sirenBoxes[currentSirenbox];
    if (box) {
        box.style.top = `${box.offsetTop - pos2}px`;
        box.style.left = `${box.offsetLeft - pos1}px`;
    }
}

function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
}

window.addEventListener('message', (event) => {
    const { _type, file, volume } = event.data;

    if (_type === 'audio') {
        playSound(file, volume);
    } else if (_type === 'hud') {
        switch (event.data.item) {
            case 'toggle':
                if (event.data.state === true) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#smart-controller-siren-box').show();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#code3-z3-siren-box').show();
                        $('#c3-slide0').show();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#whelen-handheld-siren-box').show();
                    }
                } else {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#smart-controller-siren-box').hide();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#code3-z3-siren-box').hide();
                        $('#c3-slide0').hide();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#whelen-handheld-siren-box').hide();
                    }
                }
                break;
            case 'currentSirenbox':
                currentSirenbox = event.data.texture;
                break;
            case 'setResourceName':
                resourceName = event.data.resourceName;
                break;
            case 'sirenbox':
                if (event.data.state === true) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#code3-z3-siren-box').fadeOut();
                        $('#c3-slide0').fadeOut();
                        $('#whelen-handheld-siren-box').fadeOut();
                        $('#smart-controller-siren-box').fadeIn();

                        if (event.data.standby === true) {
                            $('#fs-buttonsoff').hide();
                            $('#fs-buttonsstandby').show();
                            $('#fs-standbyon').show();
                        } else {
                            $('#fs-buttonsstandby').hide();
                            $('#fs-buttonsoff').show();
                            $('#fs-standbyon').hide();
                        }
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#smart-controller-siren-box').fadeOut();
                        $('#whelen-handheld-siren-box').fadeOut();
                        $('#code3-z3-siren-box').fadeIn();
                        $('#c3-slide0').fadeIn();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#smart-controller-siren-box').fadeOut();
                        $('#code3-z3-siren-box').fadeOut();
                        $('#c3-slide0').fadeOut();
                        $('#whelen-handheld-siren-box').fadeIn();

                        if (event.data.standby === true) {
                            $('#wh-buttonsstandby').show();
                        } else {
                            $('#wh-buttonsstandby').hide();
                        }
                    }
                } else {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#smart-controller-siren-box').fadeOut();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#code3-z3-siren-box').fadeOut();
                        $('#c3-slide0').fadeOut();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#whelen-handheld-siren-box').fadeOut();
                    }
                }
                break;
            case 'wail':
                if (event.data.state === true) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-yelpon').hide();
                        $('#fs-prtyon').hide();
                        $('#fs-wailon').show();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-yelpon').hide();
                        $('#c3-prtyon').hide();
                        $('#c3-wailon').show();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-yelpon').hide();
                        $('#wh-prtyon').hide();
                        $('#wh-wailon').show();
                    }
                } else {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-wailon').hide();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-wailon').hide();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-wailon').hide();
                    }
                }
                break;
            case 'airhorn':
                if (currentSirenbox === 'smart-controller-siren-box') {
                    if (event.data.state === true) {
                        $('#fs-airhornon').show();
                    } else {
                        $('#fs-airhornon').hide();
                    }
                } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                    if (event.data.state === true) {
                        $('#wh-airhornon').show();
                    } else {
                        $('#wh-airhornon').hide();
                    }
                }
                break;
            case 'manual':
                if (currentSirenbox === 'smart-controller-siren-box') {
                    if (event.data.state === true) {
                        $('#fs-manualon').show();
                    } else {
                        $('#fs-manualon').hide();
                    }
                } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                    if (event.data.state === true) {
                        $('#wh-manualon').show();
                    } else {
                        $('#wh-manualon').hide();
                    }
                }
                break;
            case 'yelp':
                if (event.data.state === true) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-wailon').hide();
                        $('#fs-prtyon').hide();
                        $('#fs-yelpon').show();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-wailon').hide();
                        $('#c3-prtyon').hide();
                        $('#c3-yelpon').show();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-wailon').hide();
                        $('#wh-prtyon').hide();
                        $('#wh-yelpon').show();
                    }
                } else {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-yelpon').hide();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-yelpon').hide();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-yelpon').hide();
                    }
                }
                break;
            case 'priority':
                if (event.data.state === true) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-yelpon').hide();
                        $('#fs-wailon').hide();
                        $('#fs-prtyon').show();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-wailon').hide();
                        $('#c3-yelpon').hide();
                        $('#c3-prtyon').show();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-wailon').hide();
                        $('#wh-yelpon').hide();
                        $('#wh-prtyon').show();
                    }
                } else {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-prtyon').hide();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-prtyon').hide();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-prtyon').hide();
                    }
                }
                break;
            case 'slide':
                if (currentSirenbox === 'smart-controller-siren-box') {
                    $('#fs-slide1').hide();
                    $('#fs-slide2').hide();
                    $('#fs-slide3').hide();

                    if (event.data.stage === 1) {
                        $('#fs-slide1').show();
                    } else if (event.data.stage === 2) {
                        $('#fs-slide2').show();
                    } else if (event.data.stage === 3) {
                        $('#fs-slide3').show();
                    }
                } else if (currentSirenbox === 'code3-z3-siren-box') {
                    $('#c3-slide0').hide();
                    $('#c3-slide1').hide();
                    $('#c3-slide2').hide();
                    $('#c3-slide3').hide();

                    if (event.data.stage === 1) {
                        $('#c3-slide1').show();
                    } else if (event.data.stage === 2) {
                        $('#c3-slide2').show();
                    } else if (event.data.stage === 3) {
                        $('#c3-slide3').show();
                    } else {
                        $('#c3-slide0').show();
                    }
                } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                    $('#wh-stage1').hide();
                    $('#wh-stage2').hide();
                    $('#wh-stage3').hide();

                    if (event.data.stage === 1) {
                        $('#wh-stage1').show();
                    } else if (event.data.stage === 2) {
                        $('#wh-stage2').show();
                    } else if (event.data.stage === 3) {
                        $('#wh-stage3').show();
                    }
                }
                break;
            case 'standby':
                if (event.data.state === true) {
                    $('#fs-standbyon').hide();
                    $('#fs-standbyoff').show();
                } else {
                    $('#fs-standbyon').show();
                    $('#fs-standbyoff').hide();
                }
                break;
            case 'keyLock':
                if (event.data.state === true) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-lockon').show();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-lockon').show();
                    }
                } else {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-lockon').hide();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-lockon').hide();
                    }
                }
                break;
            case 'park':
                if (event.data.state === true) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-parkon').show();
                    }
                } else if (event.data.state === false) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-parkon').hide();
                    }
                }
                break;
            case 'cruise':
                if (event.data.state === true) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-cruiseon').show();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-cruiseon').show();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-cruiseon').show();
                    }
                } else if (event.data.state === false) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-cruiseon').hide();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-cruiseon').hide();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-cruiseon').hide();
                    }
                }
                break;
            case 'rumbler':
                if (event.data.state === true) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-rumbleron').show();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-rumbleron').show();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-rumbleron').show();
                    }
                } else if (event.data.state === false) {
                    if (currentSirenbox === 'smart-controller-siren-box') {
                        $('#fs-rumbleron').hide();
                    } else if (currentSirenbox === 'code3-z3-siren-box') {
                        $('#c3-rumbleron').hide();
                    } else if (currentSirenbox === 'whelen-handheld-siren-box') {
                        $('#wh-rumbleron').hide();
                    }
                }
                break;
        }
    } else if (_type == 'setHudScale') {
        scale = event.data.scale;
        const box = document.getElementById(event.data.hud);
        if (box) {
            box.style.transform = 'scale(' + scale + ' )';
        }
    } else if (_type == 'resetHudScale') {
        const box = document.getElementById(currentSirenbox);
        if (box) {
            box.style.transform = 'scale(' + event.data.scale + ')';
        }
    } else if (_type == 'getHudScale') {
        sendData('setHudScale', { scale: scale });
    } else if (_type == 'setHudPosition') {
        try {
            const box = document.getElementById(event.data.hud);
            if (box) {
                box.style.left = event.data.position.left;
                box.style.top = event.data.position.top;
            }
        } catch (e) {
            console.log(e);
        }
    } else if (_type == 'resetHudPosition') {
        const box = document.getElementById(currentSirenbox);
        if (box) {
            const backupPos = backup[currentSirenbox];
            if (backupPos) {
                box.style.left = backupPos.left;
                box.style.top = backupPos.top;
            }
        }
    } else if (_type == 'getHudState') {
        const box = document.getElementById(currentSirenbox);
        if (box) {
            sendData('receiveHudState', { state: $(box).is(':visible') });
        }
    }
});

function playSound(fileName, volume) {
    // Look for an existing audio player by soundId
    const existingPlayer = audioPlayers.get(fileName);

    // If an existing player is found, stop and reset it
    if (existingPlayer) {
        existingPlayer.pause();
        existingPlayer.currentTime = 0; // Reset playback to the beginning
    } else {
        // Create a new Audio object and add it to the map
        const audioPlayer = new Audio(`../sounds/${fileName}.ogg`);
        audioPlayer.volume = volume;

        audioPlayers.set(fileName, audioPlayer); // Use fileName as the key for reuse
    }

    // Play the audio from the map
    const audioPlayer = audioPlayers.get(fileName);
    audioPlayer.play().catch(() => {
        audioPlayers.delete(fileName);
    });
}

function sendData(name, data) {
    $.post(`https://${resourceName}/${name}`, JSON.stringify(data), function (datab) {
        if (datab !== 'ok') {
            console.log(datab);
        }
    });
}

$(document).on('keyup contextmenu', function (event) {
    if ([27].includes(event.keyCode) || event.type === 'contextmenu') {
        const box = sirenBoxes[currentSirenbox];
        if (box) {
            sendData('setHudPosition', { left: box.style.left, top: box.style.top });
            sendData('setMoveState', false);
        }
    }
});