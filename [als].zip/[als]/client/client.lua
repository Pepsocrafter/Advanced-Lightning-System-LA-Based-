---@diagnostic disable: param-type-mismatch
local Config = require 'Config'

local sirenVehicles = {}
local hornVehicles = {}

local indicatorL, indicatorR
local indicatorTimerActive
local indicatorTimerCount = 0
local indicatorTimerDelay = 180

currentSiren = 'Whelen Cencom Sapphire'
local hudTempHidden
local backlightEnabled = false

currentSirenboxUi = 'smart-controller-siren-box'
local sirenboxDisplayed

function notify(msg)
    SetNotificationTextEntry('STRING')
    AddTextComponentString(msg)
    DrawNotification(false, false)
end

local function mergeExtras(t1, t2)
    local result = {table.unpack(t1)}
    for _, v in ipairs(t2) do
        result[#result + 1] = v
    end
    return result
end

local function releaseSound(veh, soundId, forced)
    if forced and (DoesEntityExist(veh) and not IsEntityDead(veh)) then return false end

    StopSound(soundId)
    ReleaseSoundId(soundId)

    return true
end

function isVehAllowed(indicators)
    if indicators then
        return cache.seat == -1 and not IsPedInAnyHeli(cache.ped) and not IsPedInAnyPlane(cache.ped)
    end

    return cache.seat == -1 and GetVehicleClass(cache.vehicle) == 18
        and not IsPedInAnyHeli(cache.vehicle)
        and not IsPedInAnyPlane(cache.vehicle)
        and Config.EquipmentSetups[GetEntityModel(cache.vehicle)]
end

CreateThread(function()
    for i = 1, #Config.SirenAudioBanks do
        RequestScriptAudioBank(Config.SirenAudioBanks[i], false)
    end

    while true do
        for veh, soundId in pairs(sirenVehicles) do
            if releaseSound(veh, soundId, true) then
                lib.print.verbose('releasing sirenVehicle: ', veh)
                sirenVehicles[veh] = nil
            end
        end

        for veh, soundId in pairs(hornVehicles) do
            if releaseSound(veh, soundId, true) then
                lib.print.verbose('releasing hornVehicle: ', veh)
                hornVehicles[veh] = nil
            end
        end

        Wait(1000)
    end
end)

CreateThread(function()
    while true do
        DistantCopCarSirens(false)

        if cache.vehicle and GetVehicleClass(cache.vehicle) == 18 then
            SetVehicleHasMutedSirens(cache.vehicle, true)
        end

        Wait(0)
    end
end)

CreateThread(function()
    while true do
        if isVehAllowed(false) then
            local hudHidden = IsHudHidden() or IsPauseMenuActive() or IsWarningMessageActive()
            local sirenboxEnabled = GetResourceKvpInt(('%s_%s_hud_enabled'):format(Config.storageSavePrefix, currentSirenboxUi))

            if sirenboxEnabled == 2 or sirenboxEnabled == 0 then
                if hudHidden ~= hudTempHidden then
                    hudTempHidden = hudHidden
                    SendNUIMessage({
                        _type = 'hud',
                        item = 'sirenbox',
                        standby = GetIsVehicleEngineRunning(cache.vehicle),
                        state = not hudHidden
                    })
                end
            end

            if not hudHidden and sirenboxEnabled == 2 or sirenboxEnabled == 0 then
                if currentSirenboxUi == 'smart-controller-siren-box' or currentSirenboxUi == 'whelen-handheld-siren-box' or currentSirenboxUi == 'whelen-core-siren-box' then
                    if backlightEnabled ~= GetIsVehicleEngineRunning(cache.vehicle) then
                        backlightEnabled = not backlightEnabled
                        SendNUIMessage({
                            _type = 'hud',
                            item = 'sirenbox',
                            standby = backlightEnabled,
                            state = true
                        })
                    end
                end
            end
        end

        Wait(500)
    end
end)

CreateThread(function()
    while true do
        if indicatorTimerActive then
            local vehicle = cache.vehicle

            if vehicle then
                local speed = GetEntitySpeed(vehicle) * 2.236936

                if speed < 6 then
                    indicatorTimerCount = 0
                else
                    if indicatorTimerCount > indicatorTimerDelay then
                        indicatorTimerCount = 0
                        indicatorTimerActive = false

                        if indicatorL then
                            indicatorL = false
                            PlaySoundFrontend(-1, 'NAV_UP_DOWN', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                            SetVehicleIndicatorLights(vehicle, 1, indicatorL)
                            Entity(vehicle).state:set('indicatorL', indicatorL, true)
                        end
                        if indicatorR then
                            indicatorR = false
                            PlaySoundFrontend(-1, 'NAV_UP_DOWN', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                            SetVehicleIndicatorLights(vehicle, 0, indicatorR)
                            Entity(vehicle).state:set('indicatorR', indicatorR, true)
                        end
                    else
                        indicatorTimerCount += 1
                    end
                end
            else
                indicatorTimerActive = false
                indicatorTimerCount = 0
            end
        end

        Wait(0)
    end
end)

lib.onCache('seat', function(seat)
    if seat ~= -1 then
        if cache.seat == -1 then
            SendNUIMessage({
                _type = 'hud',
                item = 'sirenbox',
                state = false
            })

            sirenboxDisplayed = false
            currentSirenboxUi = nil
        end

        return
    end

    if not Entity(cache.vehicle).state.stateEnsured then
        TriggerServerEvent('siren_controller:server:SyncState', VehToNet(cache.vehicle))

        if GetVehicleClass(cache.vehicle) == 18 and Config.EquipmentSetups[GetEntityModel(cache.vehicle)] then
            local enabledExtras = Config.EquipmentSetups[GetEntityModel(cache.vehicle)].extrasToBeEnabledOnSpawn

            for i = 1, 12 do
                local shouldEnable = false
                for _, extra in pairs(enabledExtras) do
                    if extra == i then
                        shouldEnable = true
                        break
                    end
                end

                if shouldEnable then
                    SetVehicleExtra(cache.vehicle, i, false)
                else
                    SetVehicleExtra(cache.vehicle, i, true)
                end
            end
        end
    end

    SetTimeout(0, function()
        if not isVehAllowed(false) then goto skip end

        currentSiren = Config.EquipmentSetups[GetEntityModel(cache.vehicle)].siren

        currentSirenboxUi = Config.Sirens[currentSiren].textureDict

        SendNUIMessage({
            _type = 'hud',
            item = 'currentSirenbox',
            texture = currentSirenboxUi
        })

        SetVehRadioStation(cache.vehicle, 'OFF')
        SetVehicleRadioEnabled(cache.vehicle, false)

        if not sirenboxDisplayed and GetResourceKvpInt(('%s_%s_hud_enabled'):format(Config.storageSavePrefix, currentSirenboxUi)) == 0 or GetResourceKvpInt(('%s_%s_hud_enabled'):format(Config.storageSavePrefix, currentSirenboxUi)) == 2 then
            SendNUIMessage({
                _type = 'hud',
                item = 'sirenbox',
                standby = GetIsVehicleEngineRunning(cache.vehicle),
                state = true
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'airhorn',
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'manual',
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'slide',
                stage = Entity(cache.vehicle).state.stage
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'cruise',
                state = Entity(cache.vehicle).state.cruise
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'park',
                state = Entity(cache.vehicle).state.park
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'rumbler',
                state = Entity(cache.vehicle).state.rumbler
            })

            sirenboxDisplayed = true
        end

        ::skip::

        while cache.seat == -1 and isVehAllowed(false) do
            DisableControlAction(0, 80, true) -- R
            DisableControlAction(0, 81, true) -- .
            DisableControlAction(0, 82, true) -- ,
            DisableControlAction(0, 83, true) -- =
            DisableControlAction(0, 84, true) -- -
            DisableControlAction(0, 85, true) -- Q
            DisableControlAction(0, 86, true) -- E
            DisableControlAction(0, 172, true) -- Up arrow
            Wait(0)
        end
    end)
end)

lib.onCache('vehicle', function(value)
    if cache.seat ~= -1 then return end

    if value then
        SetTimeout(0, function()
            if not isVehAllowed(false) then
                SendNUIMessage({
                    _type = 'hud',
                    item = 'sirenbox',
                    state = false
                })
                goto skip
            end

            currentSiren = Config.EquipmentSetups[GetEntityModel(cache.vehicle)].siren

            currentSirenboxUi = Config.Sirens[currentSiren].textureDict

            stage1:disable(false)
            stage2:disable(false)
            stage3:disable(false)

            SendNUIMessage({
                _type = 'hud',
                item = 'currentSirenbox',
                texture = currentSirenboxUi
            })

            SetVehRadioStation(cache.vehicle, 'OFF')
            SetVehicleRadioEnabled(cache.vehicle, false)

            SendNUIMessage({
                _type = 'hud',
                item = 'sirenbox',
                standby = false,
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'sirenbox',
                standby = GetIsVehicleEngineRunning(cache.vehicle),
                state = true
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'airhorn',
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'wail',
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'yelp',
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'priority',
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'manual',
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'slide',
                stage = 0
            })


            SendNUIMessage({
                _type = 'hud',
                item = 'cruise',
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'park',
                state = false
            })

            SendNUIMessage({
                _type = 'hud',
                item = 'rumbler',
                state = false
            })

            ::skip::

            if not Entity(cache.vehicle).state.stateEnsured then
                TriggerServerEvent('siren_controller:server:SyncState', VehToNet(cache.vehicle))

                if GetVehicleClass(cache.vehicle) == 18 and Config.EquipmentSetups[GetEntityModel(cache.vehicle)] then
                    local enabledExtras = Config.EquipmentSetups[GetEntityModel(cache.vehicle)].extrasToBeEnabledOnSpawn

                    for i = 1, 12 do
                        local shouldEnable = false
                        for _, extra in pairs(enabledExtras) do
                            if extra == i then
                                shouldEnable = true
                                break
                            end
                        end

                        if shouldEnable then
                            SetVehicleExtra(cache.vehicle, i, false)
                        else
                            SetVehicleExtra(cache.vehicle, i, true)
                        end
                    end
                end
            end

            while cache.seat == -1 and isVehAllowed(false) do
                DisableControlAction(0, 80, true) -- R
                DisableControlAction(0, 81, true) -- .
                DisableControlAction(0, 82, true) -- ,
                DisableControlAction(0, 83, true) -- =
                DisableControlAction(0, 84, true) -- -
                DisableControlAction(0, 85, true) -- Q
                DisableControlAction(0, 86, true) -- E
                DisableControlAction(0, 172, true) -- Up arrow
                Wait(0)
            end
        end)

        return
    end

    local state = Entity(cache.vehicle).state

    if not state.stateEnsured then return end

    if Config.sirenParkKill and state.sirenMode ~= 0 then
        SendNUIMessage({
            _type = 'hud',
            item = 'wail',
            state = false
        })

        SendNUIMessage({
            _type = 'hud',
            item = 'yelp',
            state = false
        })

        SendNUIMessage({
            _type = 'hud',
            item = 'priority',
            state = false
        })

        SendNUIMessage({
            _type = 'hud',
            item = 'manual',
            state = false
        })

        SendNUIMessage({
            _type = 'hud',
            item = 'standby',
            state = false
        })

        state:set('sirenMode', 0, true)
    end

    SendNUIMessage({
        _type = 'hud',
        item = 'cruise',
        state = false
    })

    SendNUIMessage({
        _type = 'hud',
        item = 'park',
        state = false
    })

    SendNUIMessage({
        _type = 'hud',
        item = 'rumbler',
        state = false
    })

    SendNUIMessage({
        _type = 'hud',
        item = 'horn',
        state = false
    })
    state:set('horn', false, true)
end)

function stateBagWrapper(keyFilter, cb)
    return AddStateBagChangeHandler(keyFilter, '', function(bagName, _, value, _, replicated)
        local netId = tonumber(bagName:gsub('entity:', ''), 10)
        if not netId then return end

        local loaded = lib.waitFor(function()
            return NetworkDoesEntityExistWithNetworkId(netId)
        end, 'Timeout while waiting for entity to exist', 5000)

        if loaded then
            local entity = NetToVeh(netId)
            local amOwner = NetworkGetEntityOwner(entity) == cache.playerId

            if amOwner == replicated then
                cb(entity, value)
            end
        end
    end)
end

stateBagWrapper('indicatorL', function(veh, value)
    SetVehicleIndicatorLights(veh, 1, value)
end)

stateBagWrapper('indicatorR', function(veh, value)
    SetVehicleIndicatorLights(veh, 0, value)
end)

stateBagWrapper('hazards', function(veh, value)
    SetVehicleIndicatorLights(veh, 0, value)
    SetVehicleIndicatorLights(veh, 1, value)
end)

stateBagWrapper('lightsOn', function(veh, value)
    SetVehicleHasMutedSirens(veh, true)
    SetVehicleSiren(veh, value)
end)

local restoreSiren = 0

local specialKeyCodes = {
    ['b_100'] = 'LMB',
    ['b_101'] = 'RMB',
    ['b_102'] = 'MMB',
    ['b_103'] = 'Mouse.ExtraBtn1',
    ['b_104'] = 'Mouse.ExtraBtn2',
    ['b_105'] = 'Mouse.ExtraBtn3',
    ['b_106'] = 'Mouse.ExtraBtn4',
    ['b_107'] = 'Mouse.ExtraBtn5',
    ['b_108'] = 'Mouse.ExtraBtn6',
    ['b_109'] = 'Mouse.ExtraBtn7',
    ['b_110'] = 'Mouse.ExtraBtn8',
    ['b_115'] = 'MouseWheel.Up',
    ['b_116'] = 'MouseWheel.Down',
    ['b_130'] = 'NumSubstract',
    ['b_131'] = 'NumAdd',
    ['b_134'] = 'Num Multiplication',
    ['b_135'] = 'Num Enter',
    ['b_137'] = 'Num1',
    ['b_138'] = 'Num2',
    ['b_139'] = 'Num3',
    ['b_140'] = 'Num4',
    ['b_141'] = 'Num5',
    ['b_142'] = 'Num6',
    ['b_143'] = 'Num7',
    ['b_144'] = 'Num8',
    ['b_145'] = 'Num9',
    ['b_170'] = 'F1',
    ['b_171'] = 'F2',
    ['b_172'] = 'F3',
    ['b_173'] = 'F4',
    ['b_174'] = 'F5',
    ['b_175'] = 'F6',
    ['b_176'] = 'F7',
    ['b_177'] = 'F8',
    ['b_178'] = 'F9',
    ['b_179'] = 'F10',
    ['b_180'] = 'F11',
    ['b_181'] = 'F12',
    ['b_182'] = 'F13',
    ['b_183'] = 'F14',
    ['b_184'] = 'F15',
    ['b_185'] = 'F16',
    ['b_186'] = 'F17',
    ['b_187'] = 'F18',
    ['b_188'] = 'F19',
    ['b_189'] = 'F20',
    ['b_190'] = 'F21',
    ['b_191'] = 'F22',
    ['b_192'] = 'F23',
    ['b_193'] = 'F24',
    ['b_194'] = 'Arrow Up',
    ['b_195'] = 'Arrow Down',
    ['b_196'] = 'Arrow Left',
    ['b_197'] = 'Arrow Right',
    ['b_198'] = 'Delete',
    ['b_199'] = 'Escape',
    ['b_200'] = 'Insert',
    ['b_201'] = 'End',
    ['b_210'] = 'Delete',
    ['b_211'] = 'Insert',
    ['b_212'] = 'End',
    ['b_1000'] = 'Shift',
    ['b_1002'] = 'Tab',
    ['b_1003'] = 'Enter',
    ['b_1004'] = 'Backspace',
    ['b_1009'] = 'PageUp',
    ['b_1008'] = 'Home',
    ['b_1010'] = 'PageDown',
    ['b_1012'] = 'CapsLock',
    ['b_1013'] = 'Control',
    ['b_1014'] = 'Right Control',
    ['b_1015'] = 'Alt',
    ['b_1055'] = 'Home',
    ['b_1056'] = 'PageUp',
    ['b_2000'] = 'Space'
}

function getKeyLabel(commandHash)
    local key = GetControlInstructionalButton(0, commandHash ~ 0x80000000, true)

    if key:find('t_') then
        return key:gsub('t_', '')
    end

    return specialKeyCodes[key] or 'unknown'
end

lib.addKeybind({
    name = 'airhorn',
    description = 'Airhorn',
    defaultKey = Config.Controls.airhorn,
    onPressed = function()
        if not isVehAllowed(false) then return end

        local state = Entity(cache.vehicle).state

        if not state.stateEnsured then return end

        if state.keyLock then
            SendNUIMessage({
                _type = 'audio',
                file = 'Locked_Press',
                volume = 0.2
            })
            notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

            return
        end

        if state.sirenMode > 0 then
            restoreSiren = state.sirenMode
            state:set('sirenMode', 0, true)
        end

        SendNUIMessage({
            _type  = 'audio',
            file   = Config.Sirens[currentSiren].pressSound,
            volume = 0.7
        })

        SendNUIMessage({
            _type  = 'hud',
            item = 'airhorn',
            state   = true,
        })

        state:set('horn', true, true)
    end,
    onReleased = function()
        if not isVehAllowed(false) then return end

        local state = Entity(cache.vehicle).state

        SetTimeout(0, function()
            state:set('horn', false, true)

            if restoreSiren > 0 then
                state:set('sirenMode', restoreSiren, true)
                restoreSiren = 0
            end
        end)

        SendNUIMessage({
            _type  = 'hud',
            item = 'airhorn',
            state   = false,
        })
    end
})

stateBagWrapper('horn', function(veh, value)
    local relHornId = hornVehicles[veh]

    if relHornId then
        if releaseSound(veh, relHornId) then
            hornVehicles[veh] = nil
        end
    end

    if not value then return end

    local soundId = GetSoundId()

    hornVehicles[veh] = soundId

    if Entity(veh).state.rumbler then
        PlaySoundFromEntity(soundId, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].rumblerAirhorn, veh, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].secondarySoundset, false, 0)
        return
    end

    local soundName = Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].airhorn
    local soundset = Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].soundset

    PlaySoundFromEntity(soundId, soundName, veh, soundset, false, 0)
end)

stateBagWrapper('sirenMode', function(veh, soundMode)
    local usedSound = sirenVehicles[veh]

    if usedSound then
        if releaseSound(veh, usedSound) then
            sirenVehicles[veh] = nil
        end
    end

    if soundMode == 0 or not soundMode then return end

    local soundId = GetSoundId()
    sirenVehicles[veh] = soundId

    local soundset = Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].soundset

    if soundMode == 1 then
        if Entity(veh).state.rumbler then
            PlaySoundFromEntity(soundId, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].rumblerWail, veh, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].secondarySoundset, false, 0)
        else
            PlaySoundFromEntity(soundId, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].wail, veh, soundset, false, 0)
        end
    elseif soundMode == 2 then
        if Entity(veh).state.rumbler then
            PlaySoundFromEntity(soundId, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].rumblerYelp, veh, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].secondarySoundset, false, 0)
        else
            PlaySoundFromEntity(soundId, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].yelp, veh, soundset, false, 0)
        end
    elseif soundMode == 3 then
        if Entity(veh).state.rumbler then
            PlaySoundFromEntity(soundId, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].rumblerPriority, veh, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].secondarySoundset, false, 0)
        else
            PlaySoundFromEntity(soundId, Config.Sirens[Config.EquipmentSetups[GetEntityModel(veh)].siren].priority, veh, soundset, false, 0)
        end
    end
end)

lib.addKeybind({
    name = 'leftIndicator',
    description = 'Left indicator',
    defaultKey = Config.Controls.leftIndicator,
    onPressed = function()
        if not isVehAllowed(true) then return end

        local state = Entity(cache.vehicle).state

        if not state.stateEnsured then return end

        if state.hazards then
            state:set('hazards', false, true)
        end

        PlaySoundFrontend(-1, 'NAV_UP_DOWN', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)

        if indicatorR then
            indicatorR = false
            state:set('indicatorR', indicatorR, true)
        end

        indicatorL = not indicatorL
        SetVehicleIndicatorLights(cache.vehicle, 1, indicatorL)
        state:set('indicatorL', indicatorL, true)

        indicatorTimerActive = true
        indicatorTimerCount = 0
    end
})

lib.addKeybind({
    name = 'rightIndicator',
    description = 'Right indicator',
    defaultKey = Config.Controls.rightIndicator,
    onPressed = function()
        if not isVehAllowed(true) then return end

        local state = Entity(cache.vehicle).state

        if not state.stateEnsured then return end

        if state.hazards then
            state:set('hazards', false, true)
        end

        PlaySoundFrontend(-1, 'NAV_UP_DOWN', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)

        if state.indicatorL then
            indicatorL = false
            state:set('indicatorL', indicatorL, true)
        end

        indicatorR = not indicatorR
        SetVehicleIndicatorLights(cache.vehicle, 0, indicatorR)
        state:set('indicatorR', indicatorR, true)

        indicatorTimerActive = true
        indicatorTimerCount = 0
    end
})

local previousSirenMode = 0

lib.addKeybind({
    name = 'sirenWail',
    description = 'Wail siren',
    defaultKey = Config.Controls.sirenWail,
    onPressed = function()
        if not isVehAllowed(false) then return end

        local state = Entity(cache.vehicle).state

        if not state.stateEnsured then return end

        if state.keyLock then
            SendNUIMessage({
                _type = 'audio',
                file = 'Locked_Press',
                volume = 0.2
            })
            notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

            return
        end

        local newSirenMode = state.sirenMode == 1 and 0 or 1

        SendNUIMessage({
            _type = 'hud',
            item  = 'wail',
            state = newSirenMode == 1,
        })

        if currentSirenboxUi == 'smart-controller-siren-box' and GetIsVehicleEngineRunning(cache.vehicle) then
            SendNUIMessage({
                _type  = 'hud',
                item = 'standby',
                state = newSirenMode == 1,
            })
        end

        SendNUIMessage({
            _type  = 'audio',
            file   = Config.Sirens[currentSiren].upgradeSound,
            volume = 0.5
        })

        state:set('sirenMode', newSirenMode, true)
    end
})

lib.addKeybind({
    name = 'sirenYelp',
    description = 'Yelp siren',
    defaultKey = Config.Controls.sirenYelp,
    onPressed = function()
        if not isVehAllowed(false) then return end

        local state = Entity(cache.vehicle).state

        if not state.stateEnsured then return end

        if state.keyLock then
            SendNUIMessage({
                _type = 'audio',
                file = 'Locked_Press',
                volume = 0.2
            })
            notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

            return
        end

        local newSirenMode = state.sirenMode == 2 and 0 or 2

        SendNUIMessage({
            _type   = 'hud',
            item    = 'yelp',
            state   = newSirenMode == 2,
        })

        if currentSirenboxUi == 'smart-controller-siren-box' and GetIsVehicleEngineRunning(cache.vehicle) then
            SendNUIMessage({
                _type  = 'hud',
                item = 'standby',
                state = newSirenMode == 2,
            })
        end

        SendNUIMessage({
            _type  = 'audio',
            file   = Config.Sirens[currentSiren].upgradeSound,
            volume = 0.5
        })

        state:set('sirenMode', newSirenMode, true)
    end
})

if Config.useTertiaryTone then
    lib.addKeybind({
        name = 'sirenPriority',
        description = 'Priority siren',
        defaultKey = Config.Controls.sirenPriority,
        onPressed = function()
            if not isVehAllowed(false) then return end

            local state = Entity(cache.vehicle).state

            if not state.stateEnsured then return end

            if state.keyLock then
                SendNUIMessage({
                    _type = 'audio',
                    file = 'Locked_Press',
                    volume = 0.2
                })
                notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

                return
            end

            local newSirenMode = state.sirenMode == 3 and 0 or 3

            SendNUIMessage({
                _type   = 'hud',
                item    = 'priority',
                state   = newSirenMode == 3,
            })

            if currentSirenboxUi == 'smart-controller-siren-box' and GetIsVehicleEngineRunning(cache.vehicle) then
                SendNUIMessage({
                    _type  = 'hud',
                    item = 'standby',
                    state = newSirenMode == 3,
                })
            end

            SendNUIMessage({
                _type  = 'audio',
                file   = Config.Sirens[currentSiren].upgradeSound,
                volume = 0.5
            })

            state:set('sirenMode', newSirenMode, true)
        end
    })
end

lib.addKeybind({
    name = 'hazards',
    description = 'Hazards',
    defaultKey = Config.Controls.hazards,
    onPressed = function()
        if not isVehAllowed(true) then return end

        local state = Entity(cache.vehicle).state

        if not state.stateEnsured then return end

        SetTimeout(750, function()
            if not IsControlPressed(0, 202) then return end

            if not state.hazards then
                indicatorL = false
                indicatorR = false
                state:set('indicatorL', false, true)
                state:set('indicatorR', false, true)
            end

            state:set('hazards', not state.hazards, true)

            SendNUIMessage({
                _type  = 'audio',
                file   = ('Hazards_%s'):format(state.hazards and 'On' or 'Off'),
                volume = 0.09
            })
        end)
    end
})

lib.addKeybind({
    name = 'keyLock',
    description = 'Sirenbox lock',
    defaultKey = Config.Controls.keyLock,
    onPressed = function()
        if not isVehAllowed(false) then return end

        local state = Entity(cache.vehicle).state

        if not state.stateEnsured then return end

        state:set('keyLock', not state.keyLock, true)
        SendNUIMessage({
            _type  = 'audio',
            file   = 'Key_Lock',
            volume = 0.25
        })

        SendNUIMessage({
            _type = 'hud',
            item = 'keyLock',
            state = state.keyLock
        })

        notify(state.keyLock and 'Sirenbox locked.' or 'Sirenbox unlocked.')
    end
})

local function applyStageExtras(vehicle, extrasToDisable, extrasToEnable)
    if extrasToDisable and extrasToEnable then
        SetVehicleAutoRepairDisabled(vehicle, true)

        for _, extra in ipairs(extrasToDisable) do
            SetVehicleExtra(vehicle, extra, 1)
        end
        for _, extra in ipairs(extrasToEnable) do
            SetVehicleExtra(vehicle, extra, 0)
        end

        SetVehicleAutoRepairDisabled(vehicle, false)
    end
end

local function handleStageChange(newStage)
    local state = Entity(cache.vehicle).state
    local vehicleModel = GetEntityModel(cache.vehicle)
    local extrasToEnable = {}
    local extrasToDisable = {}

    if newStage == 1 then
        extrasToEnable = Config.EquipmentSetups[vehicleModel].stage1Extras or {}
        extrasToDisable = mergeExtras(
            Config.EquipmentSetups[vehicleModel].stage2Extras or {},
            Config.EquipmentSetups[vehicleModel].stage3Extras or {}
        )
    elseif newStage == 2 then
        extrasToEnable = Config.EquipmentSetups[vehicleModel].stage2Extras or {}
        extrasToDisable = mergeExtras(
            Config.EquipmentSetups[vehicleModel].stage3Extras or {},
            Config.EquipmentSetups[vehicleModel].stage1Extras or {}
        )
    elseif newStage == 3 then
        extrasToEnable = Config.EquipmentSetups[vehicleModel].stage3Extras or {}
        extrasToDisable = mergeExtras(
            Config.EquipmentSetups[vehicleModel].stage2Extras or {},
            Config.EquipmentSetups[vehicleModel].stage1Extras or {}
        )
    end

    if newStage == 0 then
        state:set('lightsOn', false, true)
    elseif state.stage == 0 then
        state:set('lightsOn', true, true)
    end

    lib.print.verbose('New Stage: ', newStage)
    lib.print.verbose('Extras to enable: ', table.concat(extrasToEnable, ', '))
    lib.print.verbose('Extras to disable: ', table.concat(extrasToDisable, ', '))

    applyStageExtras(cache.vehicle, extrasToDisable, extrasToEnable)

    SendNUIMessage({
        _type = 'hud',
        item = 'slide',
        stage = newStage,
    })

    state:set('stage', newStage, true)
end

stage1 = lib.addKeybind({
    name = 'stage1',
    description = 'Stage 1',
    defaultKey = Config.Controls.stage1,
    onPressed = function()
        if not isVehAllowed(false) then return end
        local state = Entity(cache.vehicle).state
        if not state.stateEnsured then return end
        if state.keyLock then
            SendNUIMessage({
                _type = 'audio',
                file = 'Locked_Press',
                volume = 0.2
            })
            notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

            return
        end

        local previousStage = state.stage
        local newStage = previousStage == 1 and 0 or 1

        SendNUIMessage({
            _type  = 'audio',
            file   = newStage == 0 and Config.Sirens[currentSiren].offSound or Config.Sirens[currentSiren].onSound,
            volume = 0.7
        })

        handleStageChange(newStage)
    end
})

stage2 = lib.addKeybind({
    name = 'stage2',
    description = 'Stage 2',
    defaultKey = Config.Controls.stage2,
    onPressed = function()
        if not isVehAllowed(false) then return end
        local state = Entity(cache.vehicle).state
        if not state.stateEnsured then return end
        if state.keyLock then
            SendNUIMessage({
                _type = 'audio',
                file = 'Locked_Press',
                volume = 0.2
            })
            notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

            return
        end

        local previousStage = state.stage
        local newStage = previousStage == 2 and 0 or 2

        SendNUIMessage({
            _type  = 'audio',
            file   = newStage == 0 and Config.Sirens[currentSiren].offSound or Config.Sirens[currentSiren].onSound,
            volume = 0.7
        })

        handleStageChange(newStage)
    end
})

stage3 = lib.addKeybind({
    name = 'stage3',
    description = 'Stage 3',
    defaultKey = Config.Controls.stage3,
    onPressed = function()
        if not isVehAllowed(false) then return end
        local state = Entity(cache.vehicle).state
        if not state.stateEnsured then return end
        if state.keyLock then
            SendNUIMessage({
                _type = 'audio',
                file = 'Locked_Press',
                volume = 0.2
            })
            notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

            return
        end

        local previousStage = state.stage
        local newStage = previousStage == 3 and 0 or 3
        local volume = 0.7

        if currentSirenboxUi == 'code3-z3-siren-box' then
            local soundToPlay = Config.Sirens[currentSiren].onSound

            if previousStage == 0 or previousStage == 3 then
                volume = 0.15
                soundToPlay = Config.Sirens[currentSiren].stage3OffSound
            end

            SendNUIMessage({
                _type  = 'audio',
                file   = soundToPlay,
                volume = volume
            })
        else
            if previousStage == 3 then
                volume = 0.15
            end

            SendNUIMessage({
                _type  = 'audio',
                file   = newStage == 0 and Config.Sirens[currentSiren].stage3OffSound or Config.Sirens[currentSiren].onSound,
                volume = volume
            })
        end

        handleStageChange(newStage)
    end
})

if Config.cycleStageKeybind then
    lib.addKeybind({
        name = 'cycleStage',
        description = 'Cycle Stage',
        defaultKey = Config.Controls.cycleStage,
        onPressed = function()
            if not isVehAllowed(false) then return end
            local state = Entity(cache.vehicle).state
            if not state.stateEnsured then return end
            if state.keyLock then
                SendNUIMessage({
                    _type = 'audio',
                    file = 'Locked_Press',
                    volume = 0.2
                })
                notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

                return
            end

            local previousStage = state.stage
            local newStage = previousStage == 3 and 0 or previousStage + 1
            handleStageChange(newStage)

            local file = Config.Sirens[currentSiren].onSound
            local volume = 0.7

            if newStage == 0 then
                file = currentSirenboxUi == 'smart-controller-siren-box' and Config.Sirens[currentSiren].stage3OffSound or Config.Sirens[currentSiren].offSound
                if currentSirenboxUi == 'smart-controller-siren-box' then
                    volume = 0.15
                end
            end

            SendNUIMessage({
                _type  = 'audio',
                file   = file,
                volume = volume
            })
        end
    })
end

local isManualSirenActive = false

lib.addKeybind({
    name = 'manualSiren',
    description = 'Manual Siren',
    defaultKey = Config.Controls.sirenManual,
    onPressed = function()
        if isManualSirenActive then return end
        isManualSirenActive = true

        if not isVehAllowed(false) then isManualSirenActive = false return end

        local state = Entity(cache.vehicle).state
        if not state.stateEnsured then isManualSirenActive = false return end
        if state.keyLock then
            SendNUIMessage({
                _type = 'audio',
                file = 'Locked_Press',
                volume = 0.2
            })
            notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))
            isManualSirenActive = false
            return
        end

        previousSirenMode = state.sirenMode

        state:set('sirenMode', 1, true)

        SendNUIMessage({
            _type  = 'audio',
            file   = Config.Sirens[currentSiren].pressSound,
            volume = 0.7
        })

        SendNUIMessage({
            _type = 'hud',
            item = 'manual',
            state = true
        })
    end,
    onReleased = function()
        if not isManualSirenActive then return end
        isManualSirenActive = false

        if not isVehAllowed(false) then return end

        local state = Entity(cache.vehicle).state

        state:set('sirenMode', previousSirenMode, true)

        SendNUIMessage({
            _type = 'hud',
            item = 'manual',
            state = false
        })
    end
})

lib.addKeybind({
    name = 'rumblerActivate',
    description = 'Activate Rumbler',
    defaultKey = Config.Controls.rumblerActivate,
    onPressed = function()
        if not isVehAllowed(false) then return end

        local state = Entity(cache.vehicle).state

        if not state.stateEnsured then return end

        if not Config.EquipmentSetups[GetEntityModel(cache.vehicle)].useLowFreqTones then return end

        if state.keyLock then
            SendNUIMessage({
                _type = 'audio',
                file = 'Locked_Press',
                volume = 0.2
            })
            notify(('~o~Reminder~s~: Sirenbox is locked. Press %s to unlock.'):format(getKeyLabel(`+keyLock`)))

            return
        end

        SendNUIMessage({
            _type  = 'audio',
            file   = Config.Sirens[currentSiren].pressSound,
            volume = 0.7
        })

        SendNUIMessage({
            _type = 'hud',
            item = 'rumbler',
            state = not state.rumbler
        })

        state:set('rumbler', not state.rumbler, true)

        if state.sirenMode > 0 then
            state:set('sirenMode', state.sirenMode, true)
        end

        if state.horn then
            state:set('horn', true, true)
        end
    end
})

AddEventHandler('onResourceStop', function(resourceName)
    if cache.resource ~= resourceName then return end

    for i = 1, #Config.SirenAudioBanks do
        lib.print.verbose('Removing siren audio bank: ', Config.SirenAudioBanks[i])
        ReleaseNamedScriptAudioBank(Config.SirenAudioBanks[i])
    end
end)