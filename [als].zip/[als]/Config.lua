return {
    Controls = {
        -- Valid keys: https://docs.fivem.net/docs/game-references/input-mapper-parameter-ids/keyboard/

        airhorn         = 'E', -- (Default: E)
        sirenWail       = '1', -- (Default: 1)
        sirenYelp       = '2', -- (Default: 2)
        sirenPriority   = '3', -- (Default: 3)
        sirenManual     = 'R', -- (Default: R)
        rumblerActivate = '4', -- (Default: 4)
        stage1          = '6', -- (Default: 5)
        stage2          = '7', -- (Default: 6)
        stage3          = '8', -- (Default: 7)
        cycleStage      = 'Q', -- (Default: Q)
        leftIndicator   = 'LEFT', -- (Default: MINUS)
        rightIndicator  = 'RIGHT', -- (Default: EQUALS)
        hazards         = 'BACK', -- (Default: BACK)
        keyLock         = 'F9', -- (Default: F9)
        cruise          = 'F5' -- (Default: F5)
    },

    storageSavePrefix = 'californiaonline_sirencontroller', -- Example: community_name_siren_controller (THIS MUST BE UNIQUE!!)
    sirenParkKill = true, -- If true, disables sirens when the vehicle is parked (Default: true)
    useTertiaryTone = true, -- If true, will allow the use of a priority/third tone. (Default: true)
    cycleStageKeybind = true, -- If true, will enable the keybind (Default: Q) to cycle the stage. (Default: true)
    cruiseLightsPlugin = false, -- If true, enables the cruise lights plugin (Default: true)
    automaticParkModePlugin = false, -- If true, enables the automatic park mode plugin (Default: true)
    parkModeDelay = 500, -- Time (in ms) before the vehicle will automatically toggle to park mode. I don't reccomend anything lower than 500.(Default: 500)
    healthRepairThreshold = 970, -- The health at which the vehicle will NOT enter park mode, Min: 0, Max: 1000 (Default: 970)
    checkDoors = false, -- If true, will check if any of the vehicle's doors aren't latched before entering park mode. (Default: true)

    SirenPositions = { -- Default HUD positions
        ['smart-controller-siren-box'] = { position = { left = 0, top = 60 }, scale = 0.4 },
        ['code3-z3-siren-box'] = { position = { left = 0, top = 60 }, scale = 0.4 },
        ['whelen-handheld-siren-box'] = { position = { left = -4.8, top = 42 }, scale = 0.1 }
    },

    Sirens = {
         ['Whelen Cencom Sapphire'] = {         
            soundset       = 'POLICE3_SOUNDSET', -- Example: 'AWCNAME_SOUNDSET'
            secondarySoundset = 'POLICE4_SOUNDSET', -- Usually used for low freq tones
            wail           = 'SIREN_SAPPHIRE_WAIL',
            yelp           = 'SIREN_SAPPHIRE_YELP',
            airhorn        = 'SIREN_SAPPHIRE_HORN',
            priority       = 'SIREN_SAPPHIRE_PRIORITY',
            rumblerWail    = 'SIREN_SAPPHIRE_RMBLRWAIL',
            rumblerYelp    = 'SIREN_SAPPHIRE_RMBLRYELP',
            rumblerAirhorn = 'SIREN_SAPPHIRE_RMBLRHORN',
            rumblerPriority = 'SIREN_SAPPHIRE_RMBLRPRIORITY',
            downgradeSound = 'Cencom/Press',
            upgradeSound   = 'Cencom/Press',
            onSound        = 'Cencom/Press',
            offSound       = 'Cencom/Press',
            pressSound     = 'Cencom/Press',
            stage3OffSound = 'Cencom/Press',
            textureDict    = 'whelen-handheld-siren-box'
        },

        ['Federal Signal SSP3000B'] = {                     -- LOS ANGELES POLICE DEPARMENT --
            soundset       = 'POLICE5_SOUNDSET',                       
            wail           = 'SIREN_SSP3000_WAIL',
            yelp           = 'SIREN_SSP3000_YELP',
            airhorn        = 'SIREN_SSP3000_HORN',
            downgradeSound = 'SSP3000B/Downgrade',
            upgradeSound   = 'SSP3000B/Upgrade',
            onSound        = 'SSP3000B/On',
            offSound       = 'SSP3000B/Off',
            stage3OffSound = 'SSP3000B/Stage3Off',
            pressSound     = 'SSP3000B/Press',
            textureDict    = 'smart-controller-siren-box'
        },

        ['Code 3 Z3'] = {
            soundset       = 'POLICE1_SOUNDSET', -- Example: 'AWCNAME_SOUNDSET'
            secondarySoundset = 'POLICE2_SOUNDSET', -- Usually used for low freq tones
            wail           = 'SIREN_Z3_WAIL',
            yelp           = 'SIREN_Z3_YELP',
            priority       = 'SIREN_Z3_PRIORITY',
            airhorn        = 'SIREN_Z3_HORN',
            rumblerWail    = 'SIREN_Z3_RMBLRWAIL',
            rumblerYelp    = 'SIREN_Z3_RMBLRYELP',
            rumblerAirhorn = 'SIREN_Z3_RMBLRHORN',
            rumblerPriority = 'SIREN_Z3_RMBLRPRIORITY',
            downgradeSound = 'Code3Z3/Downgrade',
            upgradeSound   = 'Code3Z3/Upgrade',
            onSound        = 'Code3Z3/On',
            offSound       = 'Code3Z3/Off',
            pressSound     = 'Code3Z3/Press',
            stage3OffSound = 'Code3Z3/Stage3Off',
            textureDict    = 'code3-z3-siren-box'
        }
    },

    SirenAudioBanks = { -- All AWCs that should be loaded. You can create your own AWCs using https://github.com/BJDubb/SirenSharp, make sure you replace my AWCs and data files with yours if you make your own.
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE1',
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE2',
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE3',
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE4',
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE5',
        'DLC_SIREN_CONTROLLER_SIRENS\\POLICE6',
        'DLC_FEDERAL_SIGNAL\\SSP3000B'
    },

    EquipmentSetups = { -- Equipment setups for each vehicle
        [`gpd2`] = {
            siren = 'Federal Signal SSP3000B', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {9}, -- Extras to enable in stage 1
            stage2Extras = {8}, -- Extras to enable in stage 2
            stage3Extras = {10}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {1, 2, 3}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = false, -- Enable/disable cruise lights
            useParkMode = false, -- Enable/disable park mode
            useTimeBasedParkModes = false, -- Enable/disable time based park modes
            useLowFreqTones = true, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {7, 8, 9}, -- Extras to enable in day park mode
            nightParkModeExtras = {10}, -- Extras to enable in night park mode
            driveModeExtras = {}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {`gpd2`}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },

        [`vpd1`] = {
            siren = 'Whelen Cencom Sapphire', -- Assign a siren, must be a valid siren from the 'Sirens' table above
            stage1Extras = {}, -- Extras to enable in stage 1
            stage2Extras = {}, -- Extras to enable in stage 2
            stage3Extras = {3, 4, 5, 6}, -- Extras to enable in stage 3
            extrasToBeEnabledOnSpawn = {2}, -- Extras that will be enabled on spawn, usually spotlights, pushbumpers etc. All other unspecified extras will be disabled when the vehicle is first spawned
            useCruiseLights = true, -- Enable/disable cruise lights
            useParkMode = true, -- Enable/disable park mode
            useTimeBasedParkModes = true, -- Enable/disable time based park modes
            useLowFreqTones = true, -- Enable/disable low frequency tones
            parkModeExtras = {}, -- Extras to enable in park mode
            dayParkModeExtras = {9}, -- Extras to enable in day park mode
            nightParkModeExtras = {8}, -- Extras to enable in night park mode
            driveModeExtras = {3, 4, 5, 6}, -- Drive mode extras that will be disabled/enabled when going in/out of park mode
            carsToSyncWith = {`vpd1`}, -- (STILL TESTING THIS FEATURE, DONT ADVISE USE ON PROD SERVERS YET) Vehicles that will sync park modes with this vehicle when they're close enough
            cruiseLightExtras = {7} -- Cruise light extras that will be disabled/enabled when toggling cruise lights
        },
    },
}

